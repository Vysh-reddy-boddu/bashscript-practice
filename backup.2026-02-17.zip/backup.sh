#!/bin/bash
today=$(date +%F)
zip -r backup.$today.zip . \
-x "*.zip" ".git/*"
echo "Backup completed: backup_$today.zip"
