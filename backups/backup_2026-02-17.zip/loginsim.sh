#!/bin/bash
echo "Enter username"
read user
if [ "$user" = vyshboddu ]
then 
	echo "Welcome vyshboddu"
else
	echo "Access denied"
fi
