#!/bin/bash
zip -r backup.zip .
